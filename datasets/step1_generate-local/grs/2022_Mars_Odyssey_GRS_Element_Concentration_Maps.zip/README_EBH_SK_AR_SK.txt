TARGET_NAME: MARS
Instrument: Mars Odyssey Gamma Ray and Neutron Spectrometer Suite's (GRS) Gamma Subsystem (GS)

2001 MARS ODYSSEY GAMMA RAY SPECTROMETER ELEMENT CONCENTRATION MAPS

DATASET PAPER
Rani, A., Basu Sarbadhikari, A., Hood, D. R., Gasnault, O., Nambiar, S., & Karunatillake, S. (2022). Consolidated chemical provinces on Mars: Implications for geologic interpretations. Geophysical Research Letters, 49, e2022GL099235. https://doi.org/10.1029/2022GL099235

Contact for questions or data clarifications: Dr. Suniti Karunatillake, sunitiw@lsu.edu (wk43@cornell.edu)

1. Overview

The GS Element Concentrations are a set of Geographic Information System (GIS) compatible maps of geochemical concentrations throughout the mid-to-low latitudes of Mars. They contain data derived from cumulative gamma spectra, corresponding to the combined primary and extended mapping periods (Full "Epochal" spectra) from 8 June 2002 to 2 April 2005, and 30 April 2005 to 22 March 2006. The data are highly processed, and represent the fully-corrected, CO2 frost-free, derived elemental concentrations. These percentage mass fractions (except for Th, reported as mg/kg, i.e., ppm) for all non-radioactive species have been masked to exclude polar regions where we currently cannot adequately address dilution by the large amounts of water ice and marked by 9999.99 or blanks. Finalized and initially archived in 2010 April-May, the underlying derivation steps are comprehensively described by Boynton et al. (2007, Concentration of H, Si, Cl, K, Fe, and Th in the low- and mid-latitude regions of Mars. Journal of Geophysical Research: Planets, 112, 1–15, doi:10.1029/2007JE002887), Evans et al. (2006, Analysis of gamma ray spectra measured by Mars Odyssey. Journal of Geophysical Research: Planets, 111, E03S04, doi:10.1029/2005JE002657) and Karunatillake et al. (2007, Chemical compositions at Mars landing sites subject
to Mars Odyssey Gamma Ray Spectrometer constraints, Journal of Geophysical Research: Planets, 112, E08S90, doi:10.1029/2006JE002859).

2. Data from the GS (used interchangeably with GRS).
The decimeter depth sensitivity and laterally coarse resolution overcome the effects of fine dust mantles making GS elemental analysis ideal for primary and secondary geological process studies at regional scales. The non-collimation effect of the gamma-photon detection system reduces the spatial resolution. Therefore, the surface footprint of the GRS is enormous, defined as 4 degrees arc-radius (~240 km at the equator) centered about the nadir from which ~50% of the detected gamma photons originate (Boynton et al., 2007, Concentration of H, Si, Cl, K, Fe, and Th in the low- and mid-latitude regions of Mars. Journal of Geophysical Research: Planets, 112, 1–15, doi:10.1029/2007JE002887). GRS measures the energy spectrum of gamma photons emitted from the martian surface. Characteristic spectral peaks (Evans et al. 2006, Analysis of gamma ray spectra measured by Mars Odyssey. Journal of Geophysical Research: Planets, 111, E03S04, doi:10.1029/2005JE002657) in this spectrum allow us to measure the distribution of major rock-forming elements, along with some minor elements (Fe, Si, Ca, Al, H, Cl, S, K, & Th) in the soil and regolith of the martian landscape. There are two main processes on the martian surface that give rise to gamma photon emission. Gamma photons can be emitted from the decay of natural radioactive elements (K and Th) or emissions induced by cosmic particle interactions with the martian atmosphere and non-radioactive elements of the martian surface. Due to high abundances of H in the form of water ice in the shallow subsurface towards the poles (Feldman et al., 2004, Recharge mechanism of near-equatorial hydrogen on Mars: Atmospheric redistribution or sub-surface aquifer. Geophysical Research Letters, 31, 2–5, doi:10.1029/2004GL020661; Boynton et al., 2007 Concentration of H, Si, Cl, K, Fe, and Th in the low- and mid-latitude regions of Mars. Journal of Geophysical Research: Planets, 112, 1–15, doi:10.1029/2007JE002887), the nuclear reactions in the ground are modified to generally lowered rates. Furthermore, the mass abundances are diluted as H increases, which further reduces the gamma photon rate reaching the detector for other elements. Therefore, the chemical maps derived from the GRS are restricted to the midlatitudes, roughly within ±50 degrees latitude at a resolution of 5 × 5 degree (Boynton et al., 2007, Concentration of H, Si, Cl, K, Fe, and Th in the low- and mid-latitude regions of Mars. Journal of Geophysical Research: Planets, 112, 1–15, doi:10.1029/2007JE002887).

Earlier data are available at the NASA PDS (https://pds-geosciences.wustl.edu/missions/odyssey/grs_elements.html and https://pds-geosciences.wustl.edu/ody/ody-m-grs-5-elements-v1/odgm_xxxx/data/smoothed/), used a decade ago (cf., Boynton et al., 2007, Concentration of H, Si, Cl, K, Fe, and Th in the low- and mid-latitude regions of Mars. Journal of Geophysical Research: Planets, 112, 1–15, doi:10.1029/2007JE002887; Karunatillake et al., 2009, Chemically striking regions on Mars and Stealth revisited, Journal of Geophysical Research: Planets, 114, 1–35, doi:10.1029/2008JE003303; Gasnault et al., 2010, Quantitative geochemical mapping of martian elemental provinces. Icarus, 207, 226–247, doi:10.1016/j.icarus.2009.11.010; Taylor et al., 2010, Mapping Mars geochemically, Geology,38, 183–186, doi: 10.1130/G30470.1). This dataset is more refined and includes additional elements as used in this study, also as used in recent papers (e.g., Hood et al., 2016, Assessing the geologic evolution of Greater Thaumasia, Mars. Journal of Geophysical Research: Planets. 121, 1753–1769, doi:10.1002/2016JE005046; Hood et al.,2019, Contrasting regional soil alteration across the topographic dichotomy of Mars. Geophysical Research Letters, 46, 13668-13677, doi:10.1029/2019GL084483; Ojha et al., 2018, The Medusae Fossae Formation as the single largest source of dust on Mars. Nature Communications, 9, 1–7, doi: 10.1038/s41467-018-05291-5; Ojha et al., 2021, Amagmatic hydrothermal systems on Mars from radiogenic heat. Nature communications, 12, 1-11, doi: 10.1038/s41467-021-21762-8; Parro et al., 2017, Present-day heat flow model of Mars. Scientific Reports, 7:45629, DOI: 10.1038/srep45629 1).

FILE NAMES:

All elements are agnostic of the oxidation state
Al = aluminum 

Si = silicon

Ca = calcium 

Fe = iron

H2O = stoichiometric dihydrogen oxide, agnostic of the phase or mineralogy (e.g., chemically bound, water ice, brine, liquid, adsorbed aerosol)

Cl = chlorine

S = sulfur 

K = potassium

Th = thorium

Element Concentration Maps are archived in two formats.

*.txt for use in general analytical software labeled as (element symbol)_GS2010_(resolution).
resolution = map-projected pixel size in degrees (5 degrees by 5 degrees). For example, Th_GS2010_5x5 designates thorium concentration in equirectangular (Plate Carree) projection at 5 degree x 5 degrees.

*.xslx for use with GIS software like ArcGIS labeled as year_month_date_(native resolution)_(element symbol)_(spectral peak combination methods or peak energies in keV or spectral fit version)_(mg/kg designation as ppm)_(SmB: moving average boxcar filter arc radius in degrees)_(final projection resolution)GIS

year_month_date: processing date
native resolution: degrees
element symbol: SI symbol of the element

spectral peak combination methods or peak energies in keV or spectral fit version: multiple designations depending on gamma spectral peak analyses methods. WM designates weighted mean; new fit designates fit iteration; CapCor2 designates corrections for peaks from neutron capture; CapAndScatCor2 designates corrections for peaks from neutron capture and scatter. Evans et al. [2006] and Boynton et al. [2007] provide the underlying details.

mg/kg designation as ppm: where listed, only for thorium

moving average boxcar filter arc radius in degrees: the filter used after concentrations are derived to increase signal/noise ratio

Masked: polar latitudes excluded due to increasing hydrogen as described in Section 2.

Rebin(final projection resolution)GIS: stated in degrees

For example,
2010_04_28_5x5_Fe_WM_newfit_CapCor2_SmB10_Masked_Rebin_5x5GIS
processing date: 2010 April 28
native resolution: 5 by 5 degrees
element symbol: Fe for iron
WM_newfit: weighted mean of multiple peaks
CapCor2: corrected for peaks from neutron capture
SmB10: the moving average boxcar filter used after concentrations were derived to increase signal/noise ratio is 10 degrees of arc radius
masked to exclude polar regions
Rebin_5x5GIS: final projection is 5 by 5 degrees

2010_05_31_15x15_Al_WM_7724_7213_newfit_CapCor2_SmB25_Masked_Rebin_5x5GIS
processing date: 2010 May 31
native resolution: 15 by 15 degrees
element symbol: Al for iron
WM_7724_7213_newfit: weighted mean of 7724 and 7213 keV peaks
CapCor2: corrected for peaks from neutron capture
SmB25: the moving average boxcar filter used after concentrations were derived to increase signal/noise ratio is 25 degrees of arc radius
masked to exclude polar regions
Rebin_5x5GIS: final projection is 5 by 5 degrees


FILE CONTENT:
These datasets are equirectangular map-projected (i.e., plate carrée), separately using the -180 to 180 East (.txt files) and 0 - 360 East (.xlsx files) Longitude Conventions. The IAU2000 planetocentric reference system is used (cf., https://ode.rsl.wustl.edu/mars/pagehelp/Content/Frequently_Asked_Questions/Coordinate_System.htm).

For the *.txt files
Latitude: latitude of the pixel's centroid
Longitude: longitude of the pixel's centroid
NoData value = 9999.99, used to designate pixels without data
Wt% = estimated mass fraction at the pixel as percentage, with the exception of Th, reported as mg/kg (ppm)
Sigma = one standard Error (numerical uncertainty of the mass fraction, also reported as percentage except for Th in mg/kg)

For the *.xlsx files
CenterLat: latitude of the pixel's centroid
CenterLon: longitude of the pixel's centroid
MaxLat: latitude of the pixel's northern boundary
MinLat: latitude of the pixel's southern boundary
EastLon: longitude of the pixel's eastern boundary
WestLon: longitude of the pixel's western boundary
Concentration: estimated mass fraction at the pixel as percentage, with the exception of Th, reported as mg/kg (ppm)
Sigma: one standard Error (numerical uncertainty of the mass fraction, also reported as percentage except for Th in mg/kg)
NoData value = blank, used to designate pixels without data


3. Consolidated Geochemical Provinces
Provinces are named as A-D with corresponding latitude (lat) and longitude (lon) centroids at 5 degree x 5 degree equi-rectangular projection given in the Geochemical_Province.txt file. Pixels without values (i.e., blank) are compositionally similar to average martian crust and excluded from the delineated provinces. 

We use three multivariate cluster analyses to discern a set of internally uniform chemical provinces that reflect the compositional variability of the martian crust. The three methods  consist of non-hierarchical clustering with principal component analysis (NHC-PCA: Taylor et al., 2010, Mapping Mars geochemically, Geology,38, 183–186, doi: 10.1130/G30470.1), hierarchical clustering with principal component analysis (HC-PCA: Gasnault et al., 2010, Quantitative geochemical mapping of martian elemental provinces. Icarus, 207, 226–247, doi:10.1016/j.icarus.2009.11.010), and modified student's t-test to distinguish spatially overlapping Gaussian tail clusters (t-GTC: Karunatillake et al., 2009, Chemically striking regions on Mars and Stealth revisited, Journal of Geophysical Research: Planets, 114, 1–35, doi:10.1029/2008JE003303). 

We combine the intermediate provinces from the NHC-PCA, HC-PCA, and t-GTC methods into a consolidated map using a spatial contouring approach. A contour map of provinces is made by categorizing the regions into three levels: provinces derived from all three-methods overlapping, provinces with any two-methods overlapping, and provinces with no overlap. We demarcate the boundaries of final provinces resulting from at least two-methods overlapping, reducing the spatial uncertainty in any method. Provinces that deviate minimally from the average martian crust (AMC) composition are omitted so that the consolidated chemical province map highlights crustally distinct regions (Rani et al., 2022, Consolidated Chemical Provinces on Mars: Implications for Geologic Interpretations, Geophysical Research Letters, doi: 10.1029/2022GL099235).

Some provinces are sets of geographically dispersed regions with shared compositional trends.